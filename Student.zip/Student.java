import java.util.Scanner;

public class Student {
public static void main(String[] args) {
	int marks[]=new int[5];
	int i;
	float total=0,percentage;
	Scanner sc=new Scanner(System.in);
	for(i=0;i<5;i++) {
		System.out.println("Enter marks of sub"+(i+1));
		marks[i]=sc.nextInt();
		total=total+marks[i];
	}
	percentage=(total/500)*100;
	if(percentage>=80) {
		System.out.println("Grade is A and the percentage is:"+percentage);
	}
	else if(percentage>=60 && percentage<80) {
		System.out.println("Grade is B and the percentage is:"+percentage);
	}
	else if(percentage>40 && percentage<60) {
		System.out.println("Grade is C and the percentage is:"+percentage);
	}
	else
	{
		System.out.println("Grade is D and the percentage is:"+percentage);
	}
	}
}

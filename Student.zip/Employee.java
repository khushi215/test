import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;
public class Employee {
  public static void main(String[] args) {
	  String name;
	  int dob;
	  int mob;
	  int birthyear;
	  float monsal,annualsal,taxamount;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter employee name");
	name=sc.next();
	System.out.println("Enter employee date of birth");
	dob=sc.nextInt();
	System.out.println("Enter employee month of birth");
	mob=sc.nextInt();
	System.out.println("Enter employee birth year");
	birthyear=sc.nextInt();
	System.out.println("Enter employee monthly salary");
	monsal=sc.nextFloat();
	System.out.println("Employee name is:"+name);
	
	LocalDate today=LocalDate.now();
	LocalDate birthday=LocalDate.of(birthyear, mob, dob);
	
	Period p=Period.between(birthday, today);
	
	System.out.println(p.getDays());
	System.out.println(p.getMonths());
	System.out.println(p.getYears());
	
	annualsal=monsal*12;
	System.out.println("Employee annual salary is:"+annualsal);
	if(annualsal>5l) {
		System.out.println("taxamount is:100000");
	}
	else if(annualsal>=4l && annualsal<5l) {
		System.out.println("taxamount is:70000");
	}
	else if(annualsal>=3l && annualsal<4l) {
		System.out.println("taxamount is:45000");
		
	}else {
		System.out.println("taxamount is:12500");
	}
	
  }
}
